//Section 7, Lesson 4 Starter for Exercise 2 - Slide 14

public class PrisonTest_Student_7_4 {
    public static void main(String[] args){
        //Create a new Prisoner object
        // Prisoner_Student_7_4 prisoner1 = new Prisoner_Student_7_4("John", 6.2, 10);
        // prisoner1.think();

        //Create a new Prisoner object
        Prisoner_Student_7_4 prisoner2 = new Prisoner_Student_7_4("Mary", 5.8, 5);
        prisoner2.think();
        prisoner2.print();
        prisoner2.print(true);
    }   
}